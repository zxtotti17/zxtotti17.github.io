# raven-node [![Build Status](https://travis-ci.org/getsentry/raven-node.svg?branch=master)](https://travis-ci.org/getsentry/raven-node)

raven-node is a Node.js client for [Sentry](https://getsentry.com/).

## Resources

* [Documentation](https://docs.getsentry.com/hosted/clients/node/)
* [Bug Tracker](https://github.com/getsentry/raven-node/issues)
* [IRC](irc://chat.freenode.net/sentry) (chat.freenode.net, #sentry)
